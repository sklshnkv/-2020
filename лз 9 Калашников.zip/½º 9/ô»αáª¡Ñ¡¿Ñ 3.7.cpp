#include <iostream>
#include <fstream>

using namespace std;

{
    char str1;
    char str2;

    cout << "";
    cin.getline(str1);
    cout << "";
    cin.getline(str2);

    int len1 = strlen(str1);
    int len2 = strlen(str2);

    if (len1 > len2)
    {
        cout << len1 << ">" << len2 << endl;
    }
    else if (len2 > len1)
    {
        cout << len1 << "<" << len2 << endl;
    }
    else if (len1 == len2)
    {
        cout << len1 << "==" << len2 << endl;
    }
}
