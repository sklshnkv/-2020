#include <iostream>

#include <fstream>

using namespace std;

{
    int size1 = 7;
    int size 2 = 90;

    char A [size1][size2] = {{0}};
    for (int y=0; y<size1; y++)
    {
        for (int i=0; i<size2; i++)
        {
            in >> A [y][i];
        }
    }

    for (int y=0; y<size1; y++)
    {
        for (int i=0; i<size2; i++)
        {
            cout << A [y][i] << "";
        }
        cout << endl;
    }

    getch ();
    return 0;
}
